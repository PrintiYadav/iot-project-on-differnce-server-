/* Including library */
#include <ESP8266WiFi.h>
#include <ThingSpeak.h>
WiFiClient client;

/* Defining WiFi Credentials */
const char* ssid = "Arclabs"; /* Your SSID */
const char* password = "12AnV12@"; /* Your Password */

String  direction = "";

/* Thingspeak channel details */
unsigned long channelId =  2622542;  // Channel ID of thingspeak channel
unsigned int field1 = 1;
const char * readKey = "T04INNPXLAUJKAY9";  //Write Read API Key of Thingspeak Channel

/* Defining right and left motor pins */
int RMotor_1 = D1;/* Right Motor GPIO0(D3) */
int RMotor_2 = D2;/* Right Motor GPIO2(D4) */
int LMotor_1 = D3;/* Left Motor GPIO13(D7) */
int LMotor_2 = D4;/* Left Motor GPIO15(D8) */


void setup() {
  Serial.begin(115200);
  Serial.println("GPIO test!");

  ThingSpeak.begin(client);

  /* Initialize Motor Control Pins as Output */
  pinMode(RMotor_1, OUTPUT);
  pinMode(RMotor_2, OUTPUT);
  pinMode(LMotor_1, OUTPUT);
  pinMode(LMotor_2, OUTPUT);

  /* Connectinf to WiFi */
  connectingToWiFi();

}
void loop() {

  direction = ThingSpeak.readStringField(channelId, field1, readKey);   /* Getting field 1 value (direction) from Thingspeak */

  if (direction == "F") {
    move_forward(); /* If direction F moves Forward */
  }
  else if (direction == "B") {
    move_backward(); /* If direction B moves Backward */
  }
  else if (direction == "R") {
    turn_right(); /* If direction R moves Turn Right */
  }
  else if (direction == "L") {
    turn_left(); /* If direction L moves Turn Left */
  }
  else if (direction == "S") {
    move_stop(); /* If direction S moves Stop Moving */
  }
  direction = "";
}

void connectingToWiFi() {
  delay(3000);
  WiFi.disconnect();
  delay(1000);
  Serial.println("Connecting to WiFi");
  WiFi.begin(ssid, password);
  while ((!(WiFi.status() == WL_CONNECTED))) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("Connected");
  Serial.println("Local IP is : ");
  Serial.print((WiFi.localIP().toString()));
  delay(5000);
}

/* Move Forward */
void move_forward() {
  digitalWrite(RMotor_1, HIGH);
  digitalWrite(RMotor_2, LOW);
  digitalWrite(LMotor_1, HIGH);
  digitalWrite(LMotor_2, LOW);
  delay(2000);
  move_stop();
}

/* Move Backward */
void move_backward() {
  digitalWrite(RMotor_1, LOW);
  digitalWrite(RMotor_2, HIGH);
  digitalWrite(LMotor_1, LOW);
  digitalWrite(LMotor_2, HIGH);
  delay(2000);
  move_stop();
}

/* Turn Right */
void turn_right() {
  digitalWrite(RMotor_1, LOW);
  digitalWrite(RMotor_2, HIGH);
  digitalWrite(LMotor_1, HIGH);
  digitalWrite(LMotor_2, LOW);
  delay(2000);
  move_stop();
}

/* Turn Left */
void turn_left() {
  digitalWrite(RMotor_1, HIGH);
  digitalWrite(RMotor_2, LOW);
  digitalWrite(LMotor_1, LOW);
  digitalWrite(LMotor_2, HIGH);
  delay(2000);
  move_stop();
}

/* Stop Move */
void move_stop() {
  digitalWrite(RMotor_1, LOW);
  digitalWrite(RMotor_2, LOW);
  digitalWrite(LMotor_1, LOW);
  digitalWrite(LMotor_2, LOW);
}
